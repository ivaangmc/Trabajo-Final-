"""
services.py
Lógica de negocio: agrupa validación + acceso a datos para las
operaciones que expone el menú (cli/menu.py). El menú no debe hablar
directamente con Peewee ni con Pydantic "a mano", pasa por acá.
"""

from __future__ import annotations

import csv
from dataclasses import dataclass, field
from pathlib import Path

from pydantic import ValidationError

import repository
from models import Repuesto
from schemas import RepuestoCreate, RepuestoUpdate


class RepuestoNoEncontrado(Exception):
    """Se lanza cuando se busca un repuesto por id y no existe."""


class ActualizacionSinCambios(Exception):
    """Se lanza cuando RepuestoUpdate llega sin precio ni stock informados."""


@dataclass
class ResultadoCargaMasiva:
    """Resumen de una importación masiva desde CSV."""

    insertados: int = 0
    errores: list[tuple[int, str]] = field(default_factory=list)  # (nro_fila, motivo)


# ---------------------------------------------------------------------------
# Alta / listado / búsqueda
# ---------------------------------------------------------------------------

def alta_repuesto(datos_crudos: dict) -> Repuesto:
    """
    Valida `datos_crudos` con RepuestoCreate y, si es válido, lo
    persiste. Si la validación falla, propaga el ValidationError de
    Pydantic para que el menú lo muestre de forma legible.
    """
    datos_validados = RepuestoCreate(**datos_crudos)
    return repository.crear_repuesto(datos_validados)


def listar_todos() -> list[Repuesto]:
    return repository.listar_repuestos()


def buscar(texto: str) -> list[Repuesto]:
    return repository.buscar_por_nombre_o_marca(texto)


# ---------------------------------------------------------------------------
# Actualización / borrado
# ---------------------------------------------------------------------------

def actualizar(repuesto_id: int, datos_crudos: dict) -> Repuesto:
    """
    Valida los datos con RepuestoUpdate y actualiza el repuesto.
    Lanza RepuestoNoEncontrado o ActualizacionSinCambios según el caso.
    """
    datos_validados = RepuestoUpdate(**datos_crudos)

    if datos_validados.precio is None and datos_validados.stock is None:
        raise ActualizacionSinCambios("hay que informar precio y/o stock")

    actualizado = repository.actualizar_repuesto(repuesto_id, datos_validados)
    if actualizado is None:
        raise RepuestoNoEncontrado(f"no existe un repuesto con id {repuesto_id}")
    return actualizado


def eliminar(repuesto_id: int) -> None:
    borrado = repository.eliminar_repuesto(repuesto_id)
    if not borrado:
        raise RepuestoNoEncontrado(f"no existe un repuesto con id {repuesto_id}")


# ---------------------------------------------------------------------------
# Carga masiva desde CSV
# ---------------------------------------------------------------------------

COLUMNAS_CSV_ESPERADAS: list[str] = [
    "nombre",
    "marca",
    "modelo_auto",
    "categoria",
    "precio",
    "stock",
]


def carga_masiva_desde_csv(ruta_csv: str) -> ResultadoCargaMasiva:
    """
    Lee un CSV con columnas nombre, marca, modelo_auto, categoria,
    precio, stock. Valida cada fila con RepuestoCreate; las filas
    inválidas no frenan el proceso, se acumulan como error y se
    informan al final. Las filas válidas se insertan todas juntas
    con insert_many (repository.insertar_muchos).
    """
    path = Path(ruta_csv)
    if not path.exists():
        raise FileNotFoundError(f"no se encontró el archivo '{ruta_csv}'")

    resultado = ResultadoCargaMasiva()
    filas_validas: list[RepuestoCreate] = []

    with path.open(newline="", encoding="utf-8") as archivo:
        lector = csv.DictReader(archivo)
        for numero_fila, fila in enumerate(lector, start=2):  # fila 1 = encabezado
            try:
                datos = {
                    "nombre": fila.get("nombre", ""),
                    "marca": fila.get("marca", ""),
                    "modelo_auto": fila.get("modelo_auto", ""),
                    "categoria": fila.get("categoria", ""),
                    "precio": fila.get("precio", ""),
                    "stock": fila.get("stock", ""),
                }
                repuesto_validado = RepuestoCreate(**datos)
                filas_validas.append(repuesto_validado)
            except ValidationError as e:
                motivo = "; ".join(err["msg"] for err in e.errors())
                resultado.errores.append((numero_fila, motivo))
            except Exception as e:  # fila mal formada, columnas faltantes, etc.
                resultado.errores.append((numero_fila, str(e)))

    resultado.insertados = repository.insertar_muchos(filas_validas)
    return resultado


# ---------------------------------------------------------------------------
# Exportación a CSV
# ---------------------------------------------------------------------------

def exportar_a_csv(ruta_salida: str = "repuestos.csv") -> int:
    """
    Genera un CSV con todos los repuestos de la base, con fila de
    encabezados. Devuelve la cantidad de filas exportadas.
    """
    repuestos = repository.listar_repuestos()
    encabezados = [
        "id",
        "nombre",
        "marca",
        "modelo_auto",
        "categoria",
        "precio",
        "stock",
        "fecha_ingreso",
        "fecha_modificado",
    ]

    with open(ruta_salida, "w", newline="", encoding="utf-8") as archivo:
        escritor = csv.writer(archivo)
        escritor.writerow(encabezados)
        for r in repuestos:
            escritor.writerow(
                [
                    r.id,
                    r.nombre,
                    r.marca,
                    r.modelo_auto,
                    r.categoria,
                    r.precio,
                    r.stock,
                    r.fecha_ingreso,
                    r.fecha_modificado,
                ]
            )

    return len(repuestos)
