"""
models.py
Modelo Peewee que representa la tabla `repuesto` en la base de datos.
"""

from peewee import (
    Model,
    AutoField,
    CharField,
    FloatField,
    IntegerField,
    DateTimeField,
)

from db import database

# Categorías válidas para el campo `categoria`.
# Se usan también desde schemas.py para validar con Pydantic.
CATEGORIAS_VALIDAS: list[str] = [
    "motor",
    "frenos",
    "suspension",
    "electrico",
    "carroceria",
]


class Repuesto(Model):
    """Tabla que almacena cada repuesto del inventario."""

    id = AutoField(primary_key=True)
    nombre = CharField(null=False)
    marca = CharField(null=False)
    modelo_auto = CharField(null=False)
    categoria = CharField(null=False)
    precio = FloatField(null=False)
    stock = IntegerField(null=False)
    fecha_ingreso = DateTimeField(null=False)
    fecha_modificado = DateTimeField(null=False)

    class Meta:
        database = database
        table_name = "repuesto"
