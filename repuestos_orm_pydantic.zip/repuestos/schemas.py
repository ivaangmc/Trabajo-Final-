"""
schemas.py
Modelos Pydantic usados para validar los datos que entran al sistema
(alta y actualización de repuestos) ANTES de tocar la base de datos.

Regla del ejercicio: el dato entra por Pydantic, se valida ahí, y
recién después se persiste con Peewee. El menú no debe validar "a mano".
"""

from __future__ import annotations

from typing import Optional
from pydantic import BaseModel, Field, field_validator

# Mismas categorías que en models.py, repetidas acá para no generar
# un import circular entre schemas.py y models.py (son solo strings).
CATEGORIAS_VALIDAS: list[str] = [
    "motor",
    "frenos",
    "suspension",
    "electrico",
    "carroceria",
]


class RepuestoCreate(BaseModel):
    """Datos requeridos para dar de alta un repuesto nuevo.

    No incluye `id` (lo genera la base) ni las fechas (las
    completa el sistema en repository.py).
    """

    nombre: str = Field(..., min_length=1, description="Nombre del repuesto")
    marca: str = Field(..., min_length=1, description="Marca del repuesto")
    modelo_auto: str = Field(..., min_length=1, description="Modelo de auto compatible")
    categoria: str = Field(..., description="motor, frenos, suspension, electrico o carroceria")
    precio: float = Field(..., gt=0, description="Precio unitario, debe ser mayor a 0")
    stock: int = Field(..., ge=0, description="Cantidad en stock, debe ser >= 0")

    @field_validator("nombre", "marca", "modelo_auto")
    @classmethod
    def no_vacio(cls, v: str) -> str:
        """Evita strings vacíos o formados solo por espacios."""
        v = v.strip()
        if not v:
            raise ValueError("no puede estar vacío")
        return v

    @field_validator("categoria")
    @classmethod
    def categoria_valida(cls, v: str) -> str:
        """La categoría debe ser una de las categorías definidas."""
        v_normalizada = v.strip().lower()
        if v_normalizada not in CATEGORIAS_VALIDAS:
            opciones = ", ".join(CATEGORIAS_VALIDAS)
            raise ValueError(f"categoría inválida, debe ser una de: {opciones}")
        return v_normalizada


class RepuestoUpdate(BaseModel):
    """Datos editables de un repuesto ya existente.

    Solo precio y stock son editables según la consigna; ambos son
    opcionales porque el usuario puede querer actualizar uno solo.
    """

    precio: Optional[float] = Field(None, gt=0, description="Nuevo precio, debe ser mayor a 0")
    stock: Optional[int] = Field(None, ge=0, description="Nuevo stock, debe ser >= 0")

    @field_validator("precio", "stock")
    @classmethod
    def al_menos_uno_informado(cls, v):
        # La validación de "al menos un campo" se hace en services.py,
        # porque Pydantic valida campo por campo y no entre campos
        # cuando ambos son opcionales y None es un valor válido "vacío".
        return v
