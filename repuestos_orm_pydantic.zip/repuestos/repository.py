"""
repository.py
Capa de acceso a datos: funciones CRUD que operan directamente sobre
el modelo Peewee `Repuesto`. No contiene lógica de negocio ni de
interacción con el usuario, solo persistencia.
"""

from __future__ import annotations

from datetime import datetime
from typing import Optional

from peewee import fn

from models import Repuesto
from schemas import RepuestoCreate, RepuestoUpdate


def crear_repuesto(datos: RepuestoCreate) -> Repuesto:
    """Inserta un nuevo repuesto ya validado por Pydantic."""
    ahora = datetime.now()
    return Repuesto.create(
        nombre=datos.nombre,
        marca=datos.marca,
        modelo_auto=datos.modelo_auto,
        categoria=datos.categoria,
        precio=datos.precio,
        stock=datos.stock,
        fecha_ingreso=ahora,
        fecha_modificado=ahora,
    )


def listar_repuestos() -> list[Repuesto]:
    """Devuelve todos los repuestos cargados en la base."""
    return list(Repuesto.select().order_by(Repuesto.id))


def obtener_por_id(repuesto_id: int) -> Optional[Repuesto]:
    """Busca un repuesto por su id. Devuelve None si no existe."""
    return Repuesto.get_or_none(Repuesto.id == repuesto_id)


def buscar_por_nombre_o_marca(texto: str) -> list[Repuesto]:
    """
    Búsqueda parcial e insensible a mayúsculas/minúsculas por
    nombre o marca.
    """
    patron = f"%{texto.strip().lower()}%"
    consulta = Repuesto.select().where(
        (fn.LOWER(Repuesto.nombre) ** patron) | (fn.LOWER(Repuesto.marca) ** patron)
    )
    return list(consulta)


def actualizar_repuesto(repuesto_id: int, datos: RepuestoUpdate) -> Optional[Repuesto]:
    """
    Actualiza precio y/o stock de un repuesto existente y refresca
    `fecha_modificado`. Devuelve el repuesto actualizado, o None si
    el id no existe.
    """
    repuesto = obtener_por_id(repuesto_id)
    if repuesto is None:
        return None

    if datos.precio is not None:
        repuesto.precio = datos.precio
    if datos.stock is not None:
        repuesto.stock = datos.stock

    repuesto.fecha_modificado = datetime.now()
    repuesto.save()
    return repuesto


def eliminar_repuesto(repuesto_id: int) -> bool:
    """Elimina un repuesto por id. Devuelve True si se borró algo."""
    repuesto = obtener_por_id(repuesto_id)
    if repuesto is None:
        return False
    repuesto.delete_instance()
    return True


def insertar_muchos(lista_datos: list[RepuestoCreate]) -> int:
    """
    Inserta una lista de repuestos ya validados en una sola operación
    eficiente (insert_many), en lugar de hacer un save() por fila.
    Devuelve la cantidad de filas insertadas.
    """
    if not lista_datos:
        return 0

    ahora = datetime.now()
    filas = [
        {
            "nombre": d.nombre,
            "marca": d.marca,
            "modelo_auto": d.modelo_auto,
            "categoria": d.categoria,
            "precio": d.precio,
            "stock": d.stock,
            "fecha_ingreso": ahora,
            "fecha_modificado": ahora,
        }
        for d in lista_datos
    ]

    with Repuesto._meta.database.atomic():
        Repuesto.insert_many(filas).execute()

    return len(filas)
