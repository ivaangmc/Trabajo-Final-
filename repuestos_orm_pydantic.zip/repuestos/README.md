# Sistema de gestión de repuestos automotrices (v2 — ORM + Pydantic)

Aplicación de consola en Python para gestionar el inventario de una casa
de repuestos automotrices. Persiste los datos con **Peewee** (SQLite),
valida la entrada con **Pydantic** y permite exportar/importar reportes
en **CSV**.

## Estructura del proyecto

```
repuestos/
├── main.py              # punto de entrada, arranca el menú
├── db.py                # conexión y configuración de la base (Peewee)
├── models.py             # modelo Peewee (tabla Repuesto)
├── schemas.py             # modelos Pydantic (validación de entrada/salida)
├── repository.py          # funciones de acceso a datos (CRUD sobre Peewee)
├── services.py             # lógica de negocio (búsquedas, exportación, carga masiva)
├── cli/
│   ├── __init__.py
│   └── menu.py              # menú interactivo y manejo de entradas del usuario
├── repuestos_seed.csv        # archivo de ejemplo para la carga masiva
├── requirements.txt
└── README.md
```

## Instalación

1. (Recomendado) Crear un entorno virtual:
   ```bash
   python -m venv venv
   source venv/bin/activate   # en Windows: venv\Scripts\activate
   ```
2. Instalar dependencias:
   ```bash
   pip install -r requirements.txt
   ```

## Cómo correr el programa

```bash
python main.py
```

La primera vez que se ejecuta, se crea automáticamente el archivo
`repuestos.db` (SQLite) con la tabla `repuesto`. Cada alta, edición o
borrado impacta directo en la base, no hace falta guardar manualmente.

## Uso del menú

```
1. Agregar repuesto
2. Listar repuestos
3. Buscar repuesto (por nombre o marca)
4. Actualizar repuesto (precio / stock)
5. Eliminar repuesto
6. Carga masiva desde CSV
7. Exportar a CSV
0. Salir
```

Categorías válidas para el campo `categoria`: `motor`, `frenos`,
`suspension`, `electrico`, `carroceria`.

### Carga masiva

La opción 6 permite importar repuestos desde un CSV con las columnas
`nombre,marca,modelo_auto,categoria,precio,stock` (ver
`repuestos_seed.csv` como ejemplo). Cada fila se valida con
`RepuestoCreate` antes de insertarse:

- Las filas válidas se insertan todas juntas con `insert_many`
  (una sola operación, dentro de una transacción).
- Las filas inválidas **no frenan el proceso**: se informan al final
  con el número de fila y el motivo del error.

El archivo `repuestos_seed.csv` incluye a propósito dos filas
inválidas (precio vacío y stock negativo) para que se pueda probar
que el manejo de errores funciona correctamente.

### Exportar a CSV

La opción 7 genera un archivo CSV (por defecto `repuestos.csv`) con
todos los repuestos de la base, incluyendo fila de encabezados.

## Notas de diseño

- La validación de datos se hace **exclusivamente** con Pydantic
  (`schemas.py`); el menú no valida "a mano" con `if`, solo captura
  `ValidationError` para mostrar los mensajes de forma legible.
- `repository.py` es la única capa que sabe hablar con Peewee.
  `services.py` combina validación + repositorio para exponer
  operaciones de negocio completas, y `cli/menu.py` solo interactúa
  con el usuario.
- `id` es un `AutoField` autoincremental generado por la base (no UUID).
- `fecha_ingreso` se completa al crear el repuesto; `fecha_modificado`
  se actualiza automáticamente en cada `update`.
