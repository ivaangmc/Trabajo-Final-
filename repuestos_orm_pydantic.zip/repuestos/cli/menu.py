"""
cli/menu.py
Menú interactivo por consola. Se encarga únicamente de la interacción
con el usuario (pedir datos, mostrar resultados); toda la lógica real
vive en services.py.
"""

from __future__ import annotations

from pydantic import ValidationError

import services
from models import Repuesto
from schemas import CATEGORIAS_VALIDAS

SEPARADOR = "-" * 60


def mostrar_menu() -> None:
    print("\n" + SEPARADOR)
    print("SISTEMA DE GESTIÓN DE REPUESTOS AUTOMOTRICES")
    print(SEPARADOR)
    print("1. Agregar repuesto")
    print("2. Listar repuestos")
    print("3. Buscar repuesto (por nombre o marca)")
    print("4. Actualizar repuesto (precio / stock)")
    print("5. Eliminar repuesto")
    print("6. Carga masiva desde CSV")
    print("7. Exportar a CSV")
    print("0. Salir")
    print(SEPARADOR)


def pedir_opcion() -> str:
    return input("Elegí una opción: ").strip()


def imprimir_repuesto(r: Repuesto) -> None:
    print(
        f"  [{r.id}] {r.nombre} | marca: {r.marca} | modelo: {r.modelo_auto} | "
        f"categoría: {r.categoria} | precio: ${r.precio:.2f} | stock: {r.stock}"
    )
    print(f"       ingreso: {r.fecha_ingreso} | modificado: {r.fecha_modificado}")


def imprimir_lista(repuestos: list[Repuesto]) -> None:
    if not repuestos:
        print("No hay repuestos cargados en el inventario.")
        return
    for r in repuestos:
        imprimir_repuesto(r)


def imprimir_errores_validacion(e: ValidationError) -> None:
    print("Datos inválidos:")
    for err in e.errors():
        campo = ".".join(str(x) for x in err["loc"])
        print(f"  - {campo}: {err['msg']}")


# ---------------------------------------------------------------------------
# Opciones del menú
# ---------------------------------------------------------------------------

def opcion_agregar() -> None:
    print(f"Categorías válidas: {', '.join(CATEGORIAS_VALIDAS)}")
    datos_crudos = {
        "nombre": input("Nombre: "),
        "marca": input("Marca: "),
        "modelo_auto": input("Modelo de auto: "),
        "categoria": input("Categoría: "),
        "precio": input("Precio: "),
        "stock": input("Stock: "),
    }
    try:
        repuesto = services.alta_repuesto(datos_crudos)
        print(f"Repuesto creado con id {repuesto.id}.")
    except ValidationError as e:
        imprimir_errores_validacion(e)


def opcion_listar() -> None:
    imprimir_lista(services.listar_todos())


def opcion_buscar() -> None:
    texto = input("Nombre o marca a buscar: ")
    resultados = services.buscar(texto)
    if not resultados:
        print("No se encontraron repuestos que coincidan.")
    else:
        imprimir_lista(resultados)


def _pedir_id(mensaje: str) -> int | None:
    valor = input(mensaje).strip()
    if not valor.isdigit():
        print("El id tiene que ser un número entero.")
        return None
    return int(valor)


def opcion_actualizar() -> None:
    repuesto_id = _pedir_id("Id del repuesto a actualizar: ")
    if repuesto_id is None:
        return

    print("Dejá vacío el campo que no querés modificar.")
    precio_str = input("Nuevo precio: ").strip()
    stock_str = input("Nuevo stock: ").strip()

    datos_crudos = {}
    if precio_str:
        datos_crudos["precio"] = precio_str
    if stock_str:
        datos_crudos["stock"] = stock_str

    try:
        repuesto = services.actualizar(repuesto_id, datos_crudos)
        print("Repuesto actualizado:")
        imprimir_repuesto(repuesto)
    except ValidationError as e:
        imprimir_errores_validacion(e)
    except (services.RepuestoNoEncontrado, services.ActualizacionSinCambios) as e:
        print(f"No se pudo actualizar: {e}")


def opcion_eliminar() -> None:
    repuesto_id = _pedir_id("Id del repuesto a eliminar: ")
    if repuesto_id is None:
        return

    confirmacion = input(f"¿Confirmás eliminar el repuesto {repuesto_id}? (s/n): ").strip().lower()
    if confirmacion != "s":
        print("Operación cancelada.")
        return

    try:
        services.eliminar(repuesto_id)
        print("Repuesto eliminado.")
    except services.RepuestoNoEncontrado as e:
        print(f"No se pudo eliminar: {e}")


def opcion_carga_masiva() -> None:
    ruta = input("Ruta del archivo CSV (Enter para 'repuestos_seed.csv'): ").strip()
    if not ruta:
        ruta = "repuestos_seed.csv"

    try:
        resultado = services.carga_masiva_desde_csv(ruta)
    except FileNotFoundError as e:
        print(str(e))
        return

    print(f"Filas insertadas correctamente: {resultado.insertados}")
    if resultado.errores:
        print(f"Filas con errores ({len(resultado.errores)}):")
        for nro_fila, motivo in resultado.errores:
            print(f"  - fila {nro_fila}: {motivo}")
    else:
        print("Sin errores.")


def opcion_exportar() -> None:
    ruta = input("Nombre del archivo de salida (Enter para 'repuestos.csv'): ").strip()
    if not ruta:
        ruta = "repuestos.csv"
    cantidad = services.exportar_a_csv(ruta)
    print(f"Se exportaron {cantidad} repuestos a '{ruta}'.")


# ---------------------------------------------------------------------------
# Loop principal
# ---------------------------------------------------------------------------

ACCIONES = {
    "1": opcion_agregar,
    "2": opcion_listar,
    "3": opcion_buscar,
    "4": opcion_actualizar,
    "5": opcion_eliminar,
    "6": opcion_carga_masiva,
    "7": opcion_exportar,
}


def ejecutar_menu() -> None:
    """Bucle interactivo del menú principal. No rompe con entradas inválidas."""
    while True:
        mostrar_menu()
        opcion = pedir_opcion()

        if opcion == "0":
            print("¡Hasta luego!")
            break

        accion = ACCIONES.get(opcion)
        if accion is None:
            print("Opción inválida, probá de nuevo.")
            continue

        try:
            accion()
        except Exception as e:
            # Red de seguridad: cualquier error inesperado no debe
            # tirar abajo el programa completo.
            print(f"Ocurrió un error inesperado: {e}")
