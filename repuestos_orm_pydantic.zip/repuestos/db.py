"""
db.py
Configuración y conexión de la base de datos (Peewee).

Se usa SQLite para simplificar la entrega. El archivo de la base
se crea automáticamente la primera vez que se ejecuta el programa.
"""

from peewee import SqliteDatabase

DB_NAME: str = "repuestos.db"

# Instancia única de la base de datos, importada por models.py
database: SqliteDatabase = SqliteDatabase(DB_NAME)


def conectar_db() -> None:
    """Abre la conexión con la base de datos si no está abierta."""
    if database.is_closed():
        database.connect()


def cerrar_db() -> None:
    """Cierra la conexión con la base de datos si está abierta."""
    if not database.is_closed():
        database.close()


def inicializar_db() -> None:
    """
    Conecta la base y crea las tablas necesarias si no existen.
    Se llama una sola vez al arrancar la aplicación (main.py).
    """
    # Import diferido para evitar import circular entre db.py y models.py
    from models import Repuesto

    conectar_db()
    database.create_tables([Repuesto], safe=True)
