"""
main.py
Punto de entrada de la aplicación. Inicializa la base de datos y
arranca el menú interactivo.
"""

from db import inicializar_db, cerrar_db
from cli.menu import ejecutar_menu


def main() -> None:
    inicializar_db()
    try:
        ejecutar_menu()
    finally:
        cerrar_db()


if __name__ == "__main__":
    main()
